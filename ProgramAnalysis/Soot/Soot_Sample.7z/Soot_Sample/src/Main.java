import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import analyze.phase.CallGraphPhase;
import analyze.handler.BaseHandler;
import analyze.handler.CallGraphHandler;
import analyze.phase.BasePhase;
import analyze.utils.OptionsUtils;
import soot.PackManager;
import soot.PhaseOptions;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.jimple.toolkits.callgraph.Targets;
import soot.options.Options;

public class Main {
	public static void main(String[] args) {
		BaseHandler handler = new CallGraphHandler();
		
		List<String> paths = new ArrayList<String>();
		paths.add("C:/WorkSpace/Soot/soot_test_sample/services.apk");
		
		handler.runHandler(CallGraphHandler.packHandleArgs(paths));
		
		System.out.println("[*] DONE!");
	}
	
	private static void testCallGraphGen() {
		Options.v().set_whole_program(true);
		Options.v().set_allow_phantom_elms(true);
		Options.v().set_allow_phantom_refs(true);
		
		// exclude some pkgs for improve analyze performance
		Options.v().set_exclude(OptionsUtils.getExcludedPkg());
		Options.v().set_no_bodies_for_excluded(true);
		
		Options.v().set_process_dir(Collections.singletonList("C:/WorkSpace/Soot/soot_test_sample/Utils.jar"));
		
		PhaseOptions.v().setPhaseOption("cg.cha", "enable:false");
		PhaseOptions.v().setPhaseOption("cg.spark", "enabled:true");
		
		Scene.v().loadNecessaryClasses();
		
		List<SootMethod> entryMethod = new ArrayList<SootMethod>();
		
		for (SootClass sootClz : Scene.v().getClasses()) {
			if (sootClz.getName().equals("Utils")) {
				for (SootMethod sootMethod : sootClz.getMethods()) {
					System.out.println(sootClz.getName() + "#" + sootMethod.getName());
					entryMethod.add(sootMethod);
				}
			}
		}
		
		Scene.v().setEntryPoints(entryMethod);
		
		PackManager.v().getPack("wjtp").insertBefore(new Transform("wjtp.collectCg", new SceneTransformer() {
			
			@Override
			protected void internalTransform(String var1, Map<String, String> var2) {
				CallGraph callGraph = Scene.v().getCallGraph();
				for (SootMethod entry : entryMethod) {
	                Targets targets = new Targets(callGraph.edgesOutOf(entry));
	                while (targets.hasNext()) {
	                    SootMethod tgt = (SootMethod)targets.next();
	                    System.out.println(entry + " may call " + tgt);
	                }

				}
			}
		}), "wjtp.mhp");
		
		PackManager.v().runPacks();
		
		System.out.println("[*] DONE!");
	}
}
