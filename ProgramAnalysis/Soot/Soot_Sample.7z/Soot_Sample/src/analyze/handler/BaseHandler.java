package analyze.handler;

/**
 * 句柄抽象基类
 */
public abstract class BaseHandler {
	
	/**
	 * 句柄内具体执行的操作
	 * @param args
	 * @return 返回句柄执行状态
	 */
	protected abstract boolean handlerOperate(Object args);
	
	public void runHandler(Object args) {
		handlerOperate(args);
	}
}
