package analyze.handler;

import java.util.HashMap;
import java.util.List;

import analyze.phase.BasePhase;
import analyze.phase.CallGraphPhase;
import analyze.utils.OptionsUtils;
import analyze.utils.StoreUtils;
import soot.Main;
import soot.PackManager;
import soot.Scene;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.options.Options;

/**
 * 调用图生成句柄
 */
public class CallGraphHandler extends BaseHandler {
	
	public static final int ARG_DIRS = 0;

	public static HashMap packHandleArgs(List<String> paths) {
		HashMap<Integer, List<String>> arg = new HashMap<Integer, List<String>>();
		arg.put(ARG_DIRS, paths);
		return arg;
	}
	
	@Override
	protected boolean handlerOperate(Object args) {
		if (!(args instanceof HashMap)) {
			System.out.println("CGHandler args cant cast to HashMap");
			return false;
		}
		
		// Test for apk
		Options.v().set_force_android_jar("C:\\WorkEnv\\Android\\SDK\\platforms\\android-34\\android.jar");
		Options.v().set_src_prec(Options.src_prec_apk);
		Options.v().set_process_multiple_dex(true);

		HashMap<Integer, Object> handleArgs = (HashMap<Integer, Object>) args;
		List<String> paths = (List<String>) handleArgs.get(ARG_DIRS);
		OptionsUtils.addProcessDirs(paths);

		OptionsUtils.setupWholeProgramAnalyse();
		OptionsUtils.setupExcludePkg();
		
		Main.v().autoSetOptions();

		BasePhase cgPhase = new CallGraphPhase();
		HashMap phaseArgs = CallGraphPhase.packPhaseArgs("wjtp", "wjtp.mhp", genCGHandlerRunnable());

		Scene.v().loadNecessaryClasses();

		cgPhase.runPhase(phaseArgs);

		PackManager.v().runPacks();

		return true;
	}

	private Runnable genCGHandlerRunnable() {
		return new Runnable() {

			@Override
			public void run() {
				CallGraph callGraph = Scene.v().getCallGraph();
				callGraph.forEach((v) -> {
//					System.out.println(v.toString());
					StoreUtils.CFGStore.storeCfgEdge(v.getSrc(), v.getTgt());
				});
				System.out.println("CG Collect Done!");
				System.out.println(StoreUtils.CFGStore.genCFGJson());
			}
		};
	}

}
