package analyze.phase;

import java.util.HashMap;
import java.util.Map;

import soot.PackManager;
import soot.PhaseOptions;
import soot.SceneTransformer;
import soot.Transform;
import soot.options.Options;

/**
 * CG生成阶段调控类
 */
public class CallGraphPhase extends BasePhase {

	public static final String PACK_INSERT = "cg_pack_insert";
	
	public static final String PACK_TRANSFORMER = "cg_pack_transformer";
	
	public static final String PACK_RUNNABLE = "cg_pack_runnable";
	
	/**
	 * 封装用于CallGraphPhase的参数对象
	 * @param pack 选定插入的阶段
	 * @param transformer 选定插入的转换器，默认插入该转换器之前
	 * @param callback 指定在插入转换器内执行的Runnable
	 * @return
	 */
	public static HashMap packPhaseArgs(String pack, String transformer, Runnable callback) {
		HashMap<String, Object> args = new HashMap<String, Object>();
		args.put(PACK_INSERT, pack);
		args.put(PACK_TRANSFORMER, transformer);
		args.put(PACK_RUNNABLE, callback);
		return args;
	}
	
	/**
	 * 调用图生成时，需要注意处理的插入时机应该在cg阶段之后
	 */
	@Override
	protected void handlePhase(Object args) {
		if (!(args instanceof HashMap)) {
			System.out.println("CGPhase cant cast args to HashMap<String, String>");
			return;
		}
		
		// 不使用类继承算法，容易OOM，使用SPARK框架
		PhaseOptions.v().setPhaseOption("cg.cha", "enabled:false");
		PhaseOptions.v().setPhaseOption("cg.spark", "enabled:true");
		PhaseOptions.v().setPhaseOption("cg.spark", "on-fly-cg:false"); // avoid on-fly-cg exception
//		PhaseOptions.v().setPhaseOption("cg.spark", "ignore-types:true");
		PhaseOptions.v().setPhaseOption("cg.spark", "rta:true");
//		PhaseOptions.v().setPhaseOption("cg.spark", "simplify-offline:true");
//		PhaseOptions.v().setPhaseOption("cg.spark", "simplify-sccs:true");
		
		// 默认情况下处理全部入口
		PhaseOptions.v().setPhaseOption("cg", "all-reachable:true");
		
		HashMap<String, Object> phaseArgs = (HashMap<String, Object>) args;
		String pack = (String) phaseArgs.get(PACK_INSERT);
		String transformer = (String) phaseArgs.get(PACK_TRANSFORMER);
		Runnable runnable = (Runnable) phaseArgs.get(PACK_RUNNABLE);
		
		// 调用图生成场景下默认全程序模式，使用SceneTransformer
		PackManager.v().getPack(pack).insertBefore(new Transform(transformer + "_hooker", new SceneTransformer() {
			
			@Override
			protected void internalTransform(String phaseName, Map<String, String> options) {
				System.out.println("CGPhase run " + transformer + "_hooker ...");
				runnable.run();
			}
		}), transformer);
	}
	
}
