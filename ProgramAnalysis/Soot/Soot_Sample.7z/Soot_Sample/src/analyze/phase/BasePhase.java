package analyze.phase;

/**
 * 阶段调控抽象基类
 * 我们设定阶段处理模块由analyze.handler中的句柄模块统一编排
 * 一个句柄模块可以任意规划阶段模块
 */
public abstract class BasePhase {
	
	private BasePhase nextPhase = null;
	
	protected abstract void handlePhase(Object args);
	
	/**
	 * 指定下一阶段，若阶段为空，则本阶段执行完毕后整体阶段执行完毕
	 * @param nextPhase
	 */
	public void setNextPhase(BasePhase nextPhase) {
		this.nextPhase = nextPhase;
	}
	
	/**
	 * 开始运行阶段链条，所有阶段均共用同一个参数
	 * @param args
	 */
	public void runPhase(Object args) {
		handlePhase(args);
		if (nextPhase == null) {
			System.out.println("BasePhase All Phase Done!");
			return;
		}
		
		nextPhase.runPhase(args);
	}
}
