package analyze.utils;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;
import java.util.ArrayList;

import soot.MethodOrMethodContext;
import soot.SootMethod;

/**
 * StoreUnits 顾名思义，用以临时存储各类内容，包括但不限于CFG图此类
 * 任何可以在该文件内收敛的存储对象都可以尝试在本文件内描述
 */
public class StoreUtils {
	
	public static class CFGStore {
		/* 调用图数据结构
		 * - com:hash
		 *   - subpkg1:hash
		 *     - Clz1:hash
		 *       - SrcFunc1:hash
		 *         - TgtFunc1
		 *         - TgtFunc2
		 *       - SrcFunc2:hash
		 *         - ...
		 *     - Clz2:hash
		 *       - ...
		 *  */
		private static Map<String, Object> CFG_Store = new HashMap<>();
		
		private static final String HASH_TAG = "§";
		
		public static String genCFGJson() {
			Gson gson = new GsonBuilder()
					.setPrettyPrinting()
					.disableHtmlEscaping()
					.create();
			return gson.toJson(CFG_Store);
		}
		
		public static void storeCfgEdge(MethodOrMethodContext src, MethodOrMethodContext tgt) {
			SootMethod srcMethod = (SootMethod) src.method();
			SootMethod tgtMethod = (SootMethod) tgt.method();
			
			String srcPackageName = srcMethod.getDeclaringClass().getPackageName();
			String srcClassName = srcMethod.getDeclaringClass().getShortName();
			String srcMethodName = srcMethod.getSignature();
			
			String tgtMethodName = tgtMethod.getSignature();
			
			// 解析包名
			String[] srcPackages;
			if (srcPackageName.contains(".")) {
				srcPackages = srcPackageName.split("\\.");
			} else {
				srcPackages = new String[] {"no_pkg"};
			}
			
			// 构建调用图数据结构
			Map<String, Object> currentLevel = CFG_Store;
			
			// 处理包层级
			for (int i = 0; i < srcPackages.length; i++) {
				String pkg = srcPackages[i];
				
				if (!currentLevel.containsKey(pkg)) {
					currentLevel.put(pkg, new ArrayList<Map<String, Object>>());
				}
				
				// 如果是最后一级包，处理类和方法
				if (i == srcPackages.length - 1) {
					// 获取当前包列表
					List<Map<String, Object>> pkgList = (List<Map<String, Object>>) currentLevel.get(pkg);
					
					// 查找或创建类映射
					Map<String, Object> classMap = findOrCreateMapInList(pkgList, srcClassName);
					if (!classMap.containsKey(srcClassName)) {
						classMap.put(srcClassName, new ArrayList<Map<String, Object>>());
					}
					
					// 获取类列表
					List<Map<String, Object>> classList = (List<Map<String, Object>>) classMap.get(srcClassName);
					
					// 查找或创建方法映射
					Map<String, Object> methodMap = findOrCreateMapInList(classList, srcMethodName);
					if (!methodMap.containsKey(srcMethodName)) {
						methodMap.put(srcMethodName, new ArrayList<String>());
					}
					
					// 获取方法调用列表并添加目标方法
					List<String> callList = (List<String>) methodMap.get(srcMethodName);
					if (!callList.contains(tgtMethodName)) {
						callList.add(tgtMethodName);
					}
				} else {
					currentLevel = getCurrentMapFromList((List<Map<String, Object>>) currentLevel.get(pkg), srcPackages, i+1);
				}
			}
		}
		
		/**
		 * 从列表中获取当前映射，如果不存在则创建
		 */
		private static Map<String, Object> getCurrentMapFromList(List<Map<String, Object>> list, String[] packages, int index) {
			// 检查索引是否有效
			if (index >= packages.length) {
				return new HashMap<>();
			}
			
			String nextPkg = packages[index];
			for (Map<String, Object> map : list) {
				if (map.containsKey(nextPkg)) {
					return map;
				}
			}
			
			// 如果没有找到，创建新的映射
			Map<String, Object> newMap = new HashMap<>();
			newMap.put(nextPkg, new ArrayList<Map<String, Object>>());
			list.add(newMap);
			return newMap;
		}
		
		/**
		 * 在列表中查找或创建映射
		 */
		private static Map<String, Object> findOrCreateMapInList(List<Map<String, Object>> list, String key) {
			for (Map<String, Object> map : list) {
				if (map.containsKey(key)) {
					return map;
				}
			}
			
			// 如果没有找到，创建新的映射
			Map<String, Object> newMap = new HashMap<>();
			list.add(newMap);
			return newMap;
		}
	}
}
