package analyze.utils;

import java.util.ArrayList;
import java.util.List;

import soot.options.Options;

/**
 * Options 参数调控类
 */
public class OptionsUtils {
	
	private static List<String> excludedPkgs = new ArrayList<String>();
	
	private static List<String> processDirs = new ArrayList<String>();
	
	static {
		excludedPkgs.add("android.*"); // be careful with this
		
		excludedPkgs.add("androidx.*");
		excludedPkgs.add("soot.*");
		excludedPkgs.add("java.*");
		excludedPkgs.add("javax.*");
		excludedPkgs.add("kotlin.*");
		excludedPkgs.add("kotlinx.*");
		excludedPkgs.add("retrofit.*");
		excludedPkgs.add("retrofit2.*");
		excludedPkgs.add("sun.*");
		excludedPkgs.add("org.*");
		excludedPkgs.add("uk.*");
		excludedPkgs.add("rx.*");
		excludedPkgs.add("dalvik.*");
		excludedPkgs.add("io.*");
		excludedPkgs.add("okio.*");
		excludedPkgs.add("okhttp.*");
		excludedPkgs.add("okhttp3.*");
		
		excludedPkgs.add("java.*");
		excludedPkgs.add("jdk.*");
		excludedPkgs.add("javax.*");
		excludedPkgs.add("sun.*");
		excludedPkgs.add("org.*");
		excludedPkgs.add("uk.*");
		excludedPkgs.add("rx.*");
        excludedPkgs.add("io.*");
	}
	
	public static List<String> getExcludedPkg() {
		return excludedPkgs;
	}
	
	/**
	 * 设定全程序分析模式
	 */
	public static void setupWholeProgramAnalyse() {
		Options.v().set_whole_program(true);
		Options.v().set_allow_phantom_refs(true);
		Options.v().set_allow_phantom_elms(true);
		
		Options.v().set_ignore_resolution_errors(true);
	}
	
	/**
	 * 设定排除列表，排除部分无需解析Jimple的包路径以加快分析进度
	 */
	public static void setupExcludePkg() {
		Options.v().set_no_bodies_for_excluded(true);
		Options.v().set_exclude(getExcludedPkg());
	}
	
	/**
	 * 添加要分析的文件到处理路径
	 * @param 文件路径
	 */
	public static void addProcessDir(String path) {
		processDirs.add(path);
		Options.v().set_process_dir(processDirs);
	}
	
	/**
	 * 添加要分析的文件路径集合
	 * @param 文件路径集合
	 */
	public static void addProcessDirs(List<String> paths) {
		processDirs.addAll(paths);
		Options.v().set_process_dir(processDirs);
	}
}
